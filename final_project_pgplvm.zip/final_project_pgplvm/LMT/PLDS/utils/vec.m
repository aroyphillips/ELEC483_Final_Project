function v=vec(v)

v = v(:);