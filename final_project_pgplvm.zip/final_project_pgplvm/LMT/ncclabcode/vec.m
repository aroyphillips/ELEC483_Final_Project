function v = vec(x)
% VEC - vectorizes the input
% v = vec(x)
%

v = x(:);