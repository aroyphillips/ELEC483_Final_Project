# NCCLABCODE #

Contains shared general-purpose code for the neural coding and computation (pillow) lab.  Probably a lot of it could be better organized, but worth keeping this in your path since there are a lot of other functions / repositories that depend on it.

Location: should be synched on both bitbucket and on melville, so you can clone from either source. If you make updates, please push to to both remotes.

