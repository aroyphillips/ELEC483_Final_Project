function [xxtrue, yytrue, fftrue, centers] = load_gaus_data(dataSource)
    % given a boolean (0=MATLAB) (1=Python), loads the corresponding
    % simulated data (both datasets simulated by Roy Phillips with the same centers, different latent).
    if dataSource == 0
        datasetname = 'simdatadir/simdata3_phillips.mat';  % name of dataset
        if ~exist(datasetname,'file') % Create simulated dataset if necessary
            fprintf('Creating simulated dataset: ''%s''\n', datasetname);
            mkSimData3_2DBump;
        end
        load(datasetname);
        xxtrue = simdata.latentVariable;
        yytrue = simdata.spikes;
        fftrue = simdata.spikeRates;
        centers = simdata.centers;
    elseif dataSource ==1
        xxtrue = readmatrix('latent_bump.csv')'; 
        yytrue = readmatrix('sim_spikes_bump.csv')';
        fftrue = readmatrix('logFR_bump.csv');
        centers = readmatrix('gaus_centers.csv');
    else
        warning("dataSource must be set to 0 for matlab generated or 1 for python generated");
    end
end

