function ctrs = gen_centers(nneur, nf)
        %%% given number of neurons & latent dimensions, generates the
        %%% centers (nneur,nf)
        ctrs = gen_grid([-6 6;-6 6],round(nneur*2),nf); % generate the center of the bump
        ii = size(ctrs,1);
        jj = randperm(ii);
        ctrs = ctrs(jj(1:nneur),:);
end
