function ff_bump = ffun_bump(xx, ctrs, ell, rho)
    %% xx is (T,P), ctrs (N, P), ell & rho are hyperparametes
    if nargin <3
        % default vals
        ell = 1; % standard deviation
        rho = 20; % marginal variance
    end

    K = sq_dist(xx'/ell,ctrs'/ell);  % cross covariances Kxz

    ff_bump = rho*exp(-K/2);
        
end